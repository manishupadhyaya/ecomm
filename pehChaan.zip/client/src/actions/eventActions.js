import axios from 'axios';
import { EVENT_LOADING, CLEAR_ERRORS, GET_ERRORS } from './types';

// Add Event
// export const addEvent = eventData => dispatch => {
//     dispatch(clearErrors());
//     axios
//         .post('/api/event', eventData)
//         .then(res => history.push('/'))
//         .then(res =>
//             dispatch({
//                 type: ADD_EVENT,
//                 payload: res.data
//             })
//         )
//         .catch(err =>
//             dispatch({
//                 type: GET_ERRORS,
//                 payload: err.response.data
//             })
//         );
// };

// Create Profile
export const addEvent = (eventData, history) => dispatch => {
    axios
        .post('/api/event', eventData)
        .then(res => history.push('/'))
        .catch(err =>
            dispatch({
                type: GET_ERRORS,
                payload: err.response.data
            })
        );
};

// Set loading state
export const setEventLoading = () => {
    return {
        type: EVENT_LOADING
    };
};

// Clear errors
export const clearErrors = () => {
    return {
        type: CLEAR_ERRORS
    };
};
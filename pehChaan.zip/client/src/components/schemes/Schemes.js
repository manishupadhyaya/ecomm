import React, { Component } from 'react'
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getSchemes } from '../../actions/getSchemes';
import SchemeItem from './schemeItem'
import Spinner from '../../components/common/Spinner'

export class Schemes extends Component {
    componentDidMount() {
        this.props.getSchemes();
    }
    render() {
        const { schemes, loading } = this.props.scheme;
        let schemeItems;

        if (schemes === null || loading) {
            schemeItems = <Spinner />;
        } else {
            if (schemes.length > 0) {
                schemeItems = schemes.map(scheme => (
                    <SchemeItem
                        key={scheme._id}
                        title={scheme.title}
                        text={scheme.text}
                        link={scheme.link}
                        linktitle={scheme.linktitle}
                    />
                ));
            } else {
                schemeItems = <h4>No Schemes found...</h4>;
            }
        }

        return (
            <div className="profiles">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <h1 className="display-4 text-center">Government Schemes</h1>
                            <p className="lead text-center">
                                Browse and know the schemes
                  </p>
                            {schemeItems}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

Schemes.propTypes = {
    getSchemes: PropTypes.func.isRequired,
    schemes: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
    scheme: state.scheme
});

export default connect(mapStateToProps, { getSchemes })(Schemes)

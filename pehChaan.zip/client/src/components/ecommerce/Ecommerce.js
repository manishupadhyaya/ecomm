import React from 'react'

export default function Ecommerce() {
    return (
        <div>
            this is ecommerce section
        </div>
    )
}
